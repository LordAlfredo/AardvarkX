Welcome to AardvarkX: The ultimate annoyance tool!
This program runs best on MCPS Windows systems. There may be ways to exit out of it on other computers.
To install open (but DO NOT DECOMPRESS) the zip folder "Installer inside." Open installandrun, and click "Run" when prompted. Doing this circumvents any "no programs on external drives" policies. The AardvarkX folder MUST be on the root of a drive for it to work (AardvarkX CDs are already set up this way). After the installer quits and AardvarkX starts, the drive can be safely removed. The program now lives on the user's computer. 
AardvarkX has a few option you can set on startup. There are three activation modes.
"On focus" will activate the program with a screenshot (so the target suspects nothing) as soon an you select another window. This is useful if you need to bring a program the target had open back to the front. "Immediately" starts it, well, duh. Timer will let you set a clock time or a countdown timer to activate the program. It will be invisible until the time you set in the next window. 
Creating a backdoor password will let you interrupt and exit AardvarkX. When it's running, type a period followed by the password and AardvarkX will dissapear. AardvarkX will not show what you type, or give any indication if you are typing the correct code.
If the release at end option is checked, the program will exit after the music finishes. If not, the computer will remain locked down.

FOUND THIS ON YOUR COMPUTER AND DON'T KNOW WHAT IT IS?
The program leaves itself in the Documents folder to spread itself. If you've found this on your computer simply copy this folder to the root of a CD, flash drive, or other medium, take it to an enemy's computer, and follow the steps above. 